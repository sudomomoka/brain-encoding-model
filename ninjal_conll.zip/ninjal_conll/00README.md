# DVD Transcription files (by NINJAL)

- *.conll  (UTF-8)
  Column 0 to 9: parsed files with GiNZA   GiNZA による形態素・構文解析
  Column 10    : event ID (eid)            Event ID 
  Column 11    : absolute tense (formerly DCT) 絶対時制（元 DCT）
  Column 12    : timespan                  時間幅
  Column 13    : factuality                事実性 (FACT or NONFACT)
  Column 14    : timestamp on DVD          DVD 上の timestamp
  Column 15    : timestamp on DVD          DVD 上の timestamp    

- *.xlsx or *.txt (SJIS!)
  Column 0     : Event A
  Column 1     : Event B
  Column 2     : Relative Temporal Order  時間的順序
  Column 3     : time overlapping         時間間隔・重なり

- Note:
-- the label "瞬時～1秒未満" is changed to "瞬時から1秒未満"